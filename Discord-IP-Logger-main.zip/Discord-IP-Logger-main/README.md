# Discord IP Logger
Log IPs and have them sent directly to your discord webhook


---

This was made by me, Raz. 
This is not meant to be purposized for illegal use and is strictly for educational use.

---

Previews:

Webhook Output:
![image](https://user-images.githubusercontent.com/91196395/175132457-2a50b983-a8b0-44d9-88ef-3144743022c1.png)

Website Output:
![image](https://user-images.githubusercontent.com/91196395/175132617-8117c125-989f-45a3-890d-5a04df351909.png)
